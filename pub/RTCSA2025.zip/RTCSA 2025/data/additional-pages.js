var additionalPages = [
  /* Define additional pages here. */
  /* Each page should be an object with the following properties: */
  /* pageName: The name of the page. This will be used in the URL. */
  /* fileLocation: The location of the file to be served. */
  /* Example:
    {
      pageName: "Sponsors",
      fileLocation: "content/sponsors.html"
    }
   */
];
